<?php



class Ruta{



	/*=============================================

	RUTA LADO DEL CLIENTE

	=============================================*/	



	public function ctrRuta(){



		return "https://andamiosexpressstore.mx/";

	

	}



	/*=============================================

	RUTA LADO DEL SERVIDOR

	=============================================*/	



	public function ctrRutaServidor(){



		return "https://panel.andamiosexpressstore.mx/";

	

	}



}