<!--=====================================
MENU
======================================-->


<ul class="sidebar-menu" data-widget="tree" style="background-color: #0a0a0a;">

    <li class="active"><a href="inicio"><i class="fa fa-home"></i> <span>Inicio</span></a></li>

    <!-- <li><a href="comercio"><i class="fa fa-files-o"></i> <span>Gestor Comercio</span></a></li> -->

   <!--  <li><a href="slide"><i class="fa fa-edit"></i> <span>Gestor Slide</span></a></li> -->

    <li><a href="categorias"><i class="fa fa-th"></i> <span>Gestor Categorías</span></a></li>


    <li><a href="productos"><i class="fab fa-product-hunt"></i> <span> Gestor Productos</span></a></li>

    <!-- <li><a href="banner"><i class="fa fa-map-o"></i> <span>Gestor Banner</span></a></li>-->
	<li class="treeview">
      
      <a href="#">
      <i class="fa fa-shopping-cart"></i>
        <span>Gestor ventas</span>
        <span class="pull-right-container">
            <i class="fa fa-angle-left pull-right"></i>
        </span>
      </a>

      <ul class="treeview-menu">
        
        <li><a href="ventas"><i class="far fa-dot-circle"></i> Ventas Vía PayPal</a></li>
        <li><a href="ventas-transferencia"><i class="far fa-dot-circle"></i> Ventas Vía Transferencia</a></li>
      
      </ul>

  </li>

    <!-- <li><a href="ventas"><i class="fa fa-shopping-cart"></i> <span>Gestor Ventas</span></a></li> -->

    <li><a href="crear-venta"><i class="fa fa-shopping-cart"></i> <span>Registrar venta</span></a></li>
    
    <li><a href="usuarios"><i class="fa fa-users"></i> <span>Gestor Usuarios</span></a></li>

    <li><a href="perfiles"><i class="fa fa-key"></i> <span>Gestor Perfiles</span></a></li>

    <!--<li><a href="visitas"><i class="fa fa-map-marker"></i> <span>Gestor Visitas</span></a></li>



    <li><a href="mensajes"><i class="fa fa-envelope"></i> <span>Gestor Mensajes</span></a></li>

     -->

</ul>