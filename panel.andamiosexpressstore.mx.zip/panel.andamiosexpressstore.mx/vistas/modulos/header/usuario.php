<!--USUARIOS-->

 <!--user menu-->

 <li class="dropdown user user-menu">

    <!--dropdown toogle-->

        <a href="#" class="dropdown-toggle" data-toggle="dropdown">

            <img src="vistas/img/plantilla/logo_mobil.png" class="user-image" alt="Imagen de usuario">

            <span class="hidden-xs">Andamios Express Shop</span>

        </a>

    <!--dropdown toogle-->

    <!--dropdown menu-->

    <ul class="dropdown-menu">

        <li class="user-header">

            <img src="vistas/img/plantilla/logo_mobil.png" alt="" class="img-circle">

            <p style="color: #0a0a0a;">

                Andamios Express Shop

            </p>

        </li>

        <!--user footer-->

        <li class="user-footer">

            <div class="pull-left">

                <a href="perfiles" class="btn btn-default btn-flat">Perfil</a>

            </div>

            <div class="pull-right">

                <a href="salir" class="btn btn-default btn-flat">salir</a>

            </div>

        </li>

        <!--user footer-->

    </ul>

    <!--dropdown menu-->

 </li>

 <!--user menu-->