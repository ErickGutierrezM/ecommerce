<!--MAIN SIDE BAR-->
<aside class="main-sidebar">

    <!--SIDE BAR-->

    <section class="sidebar">
        <?php
            include "lateral/menu.php";
        ?>

    </section>
    <!--SIDE BAR-->
</aside>
<!--MAIN SIDE BAR-->