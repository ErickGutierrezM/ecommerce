<!--FOOTER-->

<footer class="main-footer">
    <strong>Copyright &copy; 2021 <a href="http://andamiosexpressstore.mx/" target="_blank">Andamios Express Store</a></strong> Todos los derechos reservados.
</footer>